Add Tasks: Allows users to add tasks with titles and descriptions.
Update Tasks: Users can modify the details of an existing task.
Delete Tasks: Tasks can be deleted when they are completed or no longer needed.

SETUP
DOWNLOAD VISUAL STUDIO 2022
1. Download the .zip file of the project and extract it to a directory on your computer.
2. Navigate to the project directory and open the solution file .sln in Visual Studio.
3. In Visual Studio,  build the solution.
4. to Debug > Start Debugging to launch the app.


IF EXPERIENCE ANY ERRORS WHEN TRYING TO RUN THE APPLICATION PRESS CONTINUE TO SEE THE APPLICATION RUNNING .
